﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace X_1_FirstWebAPI.Model
{
    public class Users
    {
        public int Id { get; set; }
        public string UName { get; set; }
        public int UAge { get; set; }
        public string UAddress { get; set; }
    }
}